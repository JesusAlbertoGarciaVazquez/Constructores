﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//su funcion consiste en mostrar los datos en tiempo de ejecucion 
[System.Serializable]

public class ConsArmas : MonoBehaviour
{
 public List <ArmasCaseras> armascaseras;

    // Start is called before the first frame update
    void Start()
    {
        //Add permite añadir nuevo elemento a mi lista "" las comillas dan el nombre de mi personaje y las comas , seguidas de un valor 
    //en este caso de vida y de magia hp y mp
        armascaseras.Add(new ArmasCaseras("Chanclas",100,50));
        armascaseras.Add(new ArmasCaseras("Palos",50,500));
        armascaseras.Add(new ArmasCaseras("Escobas",200,100));
        armascaseras.Add(new ArmasCaseras("Bombas",25,75));
        armascaseras.Add(new ArmasCaseras("Gas",150,20));
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
