﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PerPadre : MonoBehaviour
{
    public string nombre;
    public int hp;
    public int mp;

}
