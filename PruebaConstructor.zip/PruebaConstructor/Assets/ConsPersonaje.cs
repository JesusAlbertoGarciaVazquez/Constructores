﻿

//Este script es un constructor publico llamado ConsPersonaje que manejara la lista ArmasCaseras

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//su funcion consiste en mostrar los datos en tiempo de ejecucion 
[System.Serializable]

public class ConsPersonaje : MonoBehaviour
{

   public List <Personaje> personaje;

    // Start is called before the first frame update
    //se remplaza start por awake star se ejecuta solo una vez update se refresca cada 60 cuadros por segundo
    //y awake carga antes que start 
    void Awake()
    {
    //Add permite añadir nuevo elemento a mi lista "" las comillas dan el nombre de mi personaje y las comas , seguidas de un valor 
    //en este caso de vida y de magia hp y mp
        personaje.Add(new Personaje("Chairo",100,50));
        personaje.Add(new Personaje("Godin",50,500));
        personaje.Add(new Personaje("Ayuwoky",200,100));
        personaje.Add(new Personaje("Depredador",25,75));
        personaje.Add(new Personaje("Batman",150,20));
    }


    // Update is called once per frame
    void Update()
    {
        
    }
}
