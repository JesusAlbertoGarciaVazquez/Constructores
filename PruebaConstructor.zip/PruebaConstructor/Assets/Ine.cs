﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
//la herencia es algo que ya existe y que solo se terminan pasando
//todo script que escribimos en unity ya tiene un comportamiento heredada por ejemplo 
//monobehaviour como poder utilizar el sistema de comando de x-box 

public class Ine : PerPadre
{
    public string id;
    //se le llama instanciasion de un objeto y sirve para poder manipular la informacion que tengo 
    //y va a manipular de manera individual un objeto es la manera de manipular un objeto
    ConsPersonaje personaje;

    // Start is called before the first frame update
    void Start()
    {
        personaje = FindObjectOfType<ConsPersonaje>();

        if (id=="Chairo")
        {
            nombre = personaje.personaje[0].id;
            hp = personaje.personaje[0].hp;
            mp = personaje.personaje[0].mp;
            
        }
        else if (id=="Godin")
        {
            nombre = personaje.personaje[1].id;
            hp = personaje.personaje[1].hp;
            mp = personaje.personaje[1].mp;
            Debug.Log("Trae la quincena");
        }
        else if (id == "Ayuwoky")
        {
            nombre = personaje.personaje[2].id;
            hp = personaje.personaje[2].hp;
            mp = personaje.personaje[2].mp;
            Debug.Log("Trae la quincena");
        }
        else if (id == "Depredador")
        {
            nombre = personaje.personaje[3].id;
            hp = personaje.personaje[3].hp;
            mp = personaje.personaje[3].mp;
            Debug.Log("Trae la quincena");
        }
        else if (id == "Batman")
        {
            nombre = personaje.personaje[4].id;
            hp = personaje.personaje[4].hp;
            mp = personaje.personaje[4].mp;
            Debug.Log("Trae la quincena");
        }
    }

    private void Update()
    {
   
    }

}
