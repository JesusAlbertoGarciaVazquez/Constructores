﻿

//Este script es un constructor publico llamado Personaje

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//su funcion consiste en mostrar los datos en tiempo de ejecucion 
[System.Serializable]

public class Personaje 
{
    public string id;
    public int hp;
    public int mp;

    public Personaje(string id,int hp,int mp)
    {
     this.id=id;
     this.hp=hp;
     this.mp=mp;

	}
}
