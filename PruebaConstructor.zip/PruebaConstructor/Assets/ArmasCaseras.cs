﻿

//este script es otro constructor publico llamado ArmasCaseras

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//su funcion consiste en mostrar los datos en tiempo de ejecucion 
[System.Serializable]

public class ArmasCaseras 
{
    public string id;
    public int daño;
    public int dañoplus;

    public ArmasCaseras(string id,int daño,int dañoplus)
    {
     this.id=id;
     this.daño=daño;
     this.dañoplus=dañoplus;

	}
}
